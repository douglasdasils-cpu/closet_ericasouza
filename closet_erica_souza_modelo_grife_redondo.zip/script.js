
const products = [
  {name:'Conjunto Corset Premium', cat:'Conjuntos', price:'R$ 389,90', old:'', parcel:'6x de R$ 64,98', img:'produto-1.jpeg', tag:'Novo'},
  {name:'Vestido Azul Laço', cat:'Vestidos', price:'R$ 429,90', old:'', parcel:'6x de R$ 71,65', img:'produto-2.jpeg', tag:'Destaque'},
  {name:'Camisa Manga Longa Comfy', cat:'Camisas', price:'R$ 388,00', old:'', parcel:'6x de R$ 64,67', img:'produto-3.jpeg', tag:'Frete grátis'},
  {name:'Conjunto em Tricoline', cat:'Conjuntos', price:'R$ 299,00', old:'R$ 598,00', parcel:'4x de R$ 74,75', img:'produto-4.jpeg', tag:'50% OFF'},
  {name:'Camisa Super Comfy Off White', cat:'Camisas', price:'R$ 189,00', old:'R$ 378,00', parcel:'3x de R$ 63,00', img:'produto-5.jpeg', tag:'50% OFF'},
  {name:'Camisa Manga Longa Super', cat:'Camisas', price:'R$ 358,00', old:'', parcel:'5x de R$ 71,60', img:'produto-6.jpeg', tag:'Frete grátis'},
  {name:'Camisa Manga Longa', cat:'Camisas', price:'R$ 308,00', old:'', parcel:'5x de R$ 61,60', img:'produto-7.jpeg', tag:'Premium'}
];

const productsEl = document.querySelector('#products');
const buttons = document.querySelectorAll('.filters button');
const searchInput = document.querySelector('#searchInput');

function render(filter='Todos', term=''){
  const text = term.toLowerCase();
  productsEl.innerHTML = products
    .filter(p => filter === 'Todos' || p.cat === filter)
    .filter(p => p.name.toLowerCase().includes(text) || p.cat.toLowerCase().includes(text))
    .map(p => `
      <article class="product">
        <span class="tag">${p.tag}</span>
        <div class="product-photo"><img src="assets/img/${p.img}" alt="${p.name}"></div>
        <h3>${p.name}</h3>
        <div>${p.old ? `<span class="old">${p.old}</span>` : ''}<span class="price">${p.price}</span></div>
        <div class="installment">${p.parcel} sem juros</div>
        <a target="_blank" href="https://wa.me/556196278229?text=Olá! Tenho interesse no produto: ${encodeURIComponent(p.name)}">Comprar pelo WhatsApp</a>
      </article>
    `).join('');
}
render();

buttons.forEach(btn => {
  btn.onclick = () => {
    buttons.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    render(btn.dataset.filter, searchInput.value);
  };
});

searchInput?.addEventListener('input', e => render('Todos', e.target.value));
document.querySelector('#mobileMenu')?.addEventListener('click', () => document.querySelector('#nav').classList.toggle('open'));
document.querySelector('#topBtn')?.addEventListener('click', () => window.scrollTo({top:0, behavior:'smooth'}));
